<?php require_once('includes/initialization.php'); ?>
<?php if($session->is_logged_in()){ redirect_to('public/index.php'); } ?>
<?php include_login_template('header.php'); ?>
<div class="row">
	<div class="col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
		<div class="login-panel panel panel-default">
			<div class="panel-heading">G-SYS || Sign In</div>
			<div class="panel-body">
				<form id="user_login" role="form" method="post">
					<fieldset>
						<div class="form-group">
							<div id="email_error"></div>
							<input id="email" class="form-control" placeholder="E-mail" name="email" type="email" autofocus="">
						</div>
						<div class="form-group">
							<div id="password_error"></div>
							<input id="password" class="form-control" placeholder="Password" name="password" type="password" value="">
						</div>
						<button id="login" type="submit" name="login" class="btn btn-success">Login</button>
					</fieldset>
				</form>
			</div>
		</div>
	</div><!-- /.col-->
</div><!-- /.row -->
<?php include_login_template('footer.php'); ?>
		

