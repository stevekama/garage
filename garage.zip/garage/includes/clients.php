<?php
require_once('initialization.php');
class Clients extends Databaseobject {
    protected static $table_name = "clients";
    protected static $db_fields = array("id", "firstname", "lastname", "id_number", "gender", "phone", "email", "address", "location");

    public $id;
    public $firstname;
    public $lastname;
    public $id_number;
    public $gender;
    public $phone;
    public $email;
    public $address;
    public $location;

    public function full_names(){
        if(isset($this->firstname) && isset($this->lastname)){
            return $this->firstname ." ". $this->lastname;
        }
    }

    public static function find_all_clients(){
        global $database;
        $sql = "SELECT * FROM ".self::$table_name." ";
        $sql .= "ORDER BY id DESC";
        return $database->query($sql);
    }

}




?>