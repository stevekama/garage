<?php
require_once('initialization.php');

class Employees extends Databaseobject{

    protected static $table_name = "employees";
    protected static $db_fields = array("id", "firstname", "lastname", "id_number", "gender", "phone", "email", "address", "location", "date_joined", "specialisation");

    public $id;
    public $firstname;
    public $lastname;
    public $id_number;
    public $gender;
    public $phone;
    public $email;
    public $address;
    public $location;
    public $date_joined;
    public $specialisation;

    public function full_names(){
        if(isset($this->firstname) && isset($this->lastname)){
            return $this->firstname ." ". $this->lastname;
        }
    }

    public static function find_all_employees(){
        global $database;
        $sql = "SELECT * FROM ".self::$table_name." ";
        $sql .= "ORDER BY id DESC";
        return $database->query($sql);
    }
    public static function find_employee_service($service = ''){
        global $database;

        $service = $database->escape_value($service);
        $sql = "SELECT * FROM ".self::$table_name." WHERE specialisation = '{$service}' ORDER BY id ASC";
        return self::find_by_sql($sql);
    }




}




?>
