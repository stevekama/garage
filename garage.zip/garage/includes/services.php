<?php
require_once('initialization.php');

class Services extends Databaseobject{

    protected static $table_name = "services";
    protected static $db_fields = array("id", "service", "price", "description");

    public $id;
    public $service;
    public $price;
    public $description;

    public static function find_all_services(){
        global $database;

        $sql="SELECT * FROM ".self::$table_name." ";
        return $database->query($sql);
    }

}




?>
