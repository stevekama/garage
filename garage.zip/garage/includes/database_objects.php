<?php

require_once('initialization.php');

class Databaseobject{

    //http://www.php.net/lsb

    public static function find_all(){
        return static::find_by_sql("SELECT * FROM ".static::$table_name." ORDER BY id DESC");
    }

    public static function find_by_id($id=0){
        global $database;

        $safe_id = $database->escape_value($id);
        $result_array = static::find_by_sql("SELECT * FROM ".static::$table_name." WHERE id={$safe_id} LIMIT 1");
        return !empty($result_array) ? array_shift($result_array) : false;
    }


    public static function find_by_sql($sql=""){
        global $database;
        $result_set = $database->query($sql);
        $object_array = array();
        while($row = $database->fetch_array($result_set)){
            $object_array[]= static::instantiate($row);
        }
        return $object_array;

    }

    private function has_attribute($attribute){
        $object_vars = $this->attribubes();
        return array_key_exists($attribute, $object_vars);
    }

    protected function attribubes(){
        //returns an array of attribute names and there values
        $attributes = array();
        foreach(static::$db_fields as $fields){
            if(property_exists($this, $fields)){
                $attributes[$fields] = $this->$fields;
            }
        }
        return $attributes;

    }

    protected function sanitized_attributes(){
        global $database;
        $clean_attributes = array();
        /*
         * Sanitize attributes before submitting
         * NOTE: Does not alter the actual value of each attribute
         */
        foreach($this->attribubes() as $key=>$value){
            $clean_attributes[$key] = $database->escape_value($value);
        }
        return $clean_attributes;
    }



    private static function instantiate($record){
        $object = new static;
//        $object->id         = $record['id'];
//        $object->username   = $record['username'];
//        $object->password   = $record['password'];
//        $object->fullnames = $record['fullnames'];
        //more dynamic, short-form approach

        foreach($record as $attribute=>$value){
            if($object->has_attribute($attribute)){
                $object->$attribute = $value;
            }

        }

        return $object;
    }

    public function create(){
        global $database;

        $attributes = $this->sanitized_attributes();
        $sql = "INSERT INTO ".static::$table_name."(";
        $sql .= join(", ", array_keys($attributes));
        $sql .=")VALUES('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
        if($database->query($sql)){
            $this->id = $database->insert_id();
            return true;
        }else{
            return false;
        }

    }

    public function update(){
        global $database;

        $attribute = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach($attribute as $key => $value){
            $attribute_pairs[] = "{$key} = '{$value}'";
        }
        $sql = "UPDATE ".static::$table_name." SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE id = ".$database->escape_value($this->id);
        $database->query($sql);
        return ($database->affected_rows()==1) ? true : false;
    }

    public function save(){
        /*
         * if the current id exists update information
         * if not save
         * help avoid check if the method function exists or not
         */
        return isset($this->id) ? $this->update() : $this->create();
    }

    public function delete(){
        global $database;

        $sql = "DELETE FROM ".static::$table_name." ";
        $sql .= "WHERE id = ".$database->escape_value($this->id)." ";
        $sql .= "LIMIT 1";
        $database->query($sql);
        return ($database->affected_rows()==1) ? true : false;


    }

}