<?php
/**
 * Define core path
 * Define them as absolute paths to make sure require_once works
 * DIRECTORY SEPERATOR is a php defined function
 * (\for windows / for linux)
 */
defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);
//this define the path root of the site
defined('SITE_ROOT') ? null : define('SITE_ROOT', DS.'xampp'.DS.'htdocs'.DS.'garage');
//this will define the path of the 'includes'. system files.
defined('LIB_PATH') ? null : define('LIB_PATH', SITE_ROOT.DS.'includes');
//this will define the path of the 'public'. system files.
defined('SYS_PATH') ? null : define('SYS_PATH', SITE_ROOT.DS.'public');
//Database connection.
require_once(LIB_PATH.DS.'database.php');
//include the database objects
require_once(LIB_PATH.DS.'database_objects.php');
//load all normal functions first
require_once(LIB_PATH.DS.'functions.php');
//load sessions
require_once(LIB_PATH.DS.'session.php');
//users and user login and deal with users authentication
require_once(LIB_PATH.DS.'users.php');
require_once(LIB_PATH.DS.'employees.php');
require_once(LIB_PATH.DS.'services.php');
require_once(LIB_PATH.DS.'stocks.php');
require_once(LIB_PATH.DS.'clients.php');


?>