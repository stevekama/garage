<?php
require_once('initialization.php');
class Vehicles extends Databaseobject{

    protected static $table_name = "vehicle";
    protected static $db_fields = array("id", "client_id", "make", "model", "plate_number");

    public $id;
    public $client_id;
    public $make;
    public $model;
    public $plate_number;



    public static function find_all_vehicles(){
        global $database;
        $sql = "SELECT * FROM ".self::$table_name." ";
        $sql .= "ORDER BY id DESC";
        return $database->query($sql);
    }

    public static function find_clients_vehicle($client_id = ""){
        global $database;
        $client_id = $database->escape_value($client_id);
        $sql = "SELECT * FROM ".self::$table_name." WHERE client_id = '{$client_id}' ORDER BY id ASC";
        return self::find_by_sql($sql);
    }

    public static function find_num_clients_vehicles($client_id = ""){
        global $database;
        $client_id = $database->escape_value($client_id);
        $sql = "SELECT * FROM ".self::$table_name." WHERE client_id = '{$client_id}' ORDER BY id ASC";
        return $database->query($sql);
    }

}


?>