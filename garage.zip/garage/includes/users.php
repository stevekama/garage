<?php
require_once('initialization.php');
class Users extends Databaseobject{
    protected static $table_name = "users";
    protected static $db_fields = array("id", "firstname", "lastname", "phone", "email", "username", "usertype", "password");

    public $id;
    public $firstname;
    public $lastname;
    public $phone;
    public $email;
    public $username;
    public $usertype;
    public $password;

    public static function authenticate($email="", $password=""){
        global $database;
        $email = $database->escape_value($email);
        $password = $database->escape_value($password);

        $sql = "SELECT * FROM ".self::$table_name." ";
        $sql .= "WHERE email = '{$email}' ";
        $sql .= "AND password = '{$password}' ";
        $sql .= "LIMIT 1";
        $result_array = self::find_by_sql($sql);
        return !empty($result_array) ? array_shift($result_array) : false;

    }

}


?>