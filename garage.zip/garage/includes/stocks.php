<?php
require_once('initialization.php');

class Stocks extends Databaseobject{

    protected static $table_name = "stocks";
    protected static $db_fields = array("id", "stock", "serial", "brand", "qty_available", "qty_received", "price", "total", "date");

    public $id;
    public $stock;
    public $serial;
    public $brand;
    public $qty_available;
    public $qty_received;
    public $price;
    public $total;
    public $date;

    public static function find_all_stocks(){
        global $database;
        $sql = "SELECT * FROM ".self::$table_name;
        return $database->query($sql);
    }

}




?>
