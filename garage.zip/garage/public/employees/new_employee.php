<?php require_once('../../includes/initialization.php') ?>
<?php
if(isset($_POST['enter_employee']) && empty($_POST['employee_id'])){
    $employee = new Employees();
    $employee->firstname = $database->escape_value($_POST['firstname']);
    $employee->lastname = $database->escape_value($_POST['lastname']);
    $employee->id_number = $database->escape_value($_POST['id_number']);
    $employee->gender = $database->escape_value($_POST['gender']);
    $employee->phone = $database->escape_value($_POST['phone']);
    $employee->email = $database->escape_value($_POST['email']);
    $employee->address = $database->escape_value($_POST['address']);
    $employee->location = $database->escape_value($_POST['location']);
    $employee->date_joined = $database->escape_value($_POST['date_joined']);
    $employee->specialisation = $database->escape_value($_POST['specialisation']);
    if($employee->save()){
        echo "new";
    }else{
        echo "failed";
    }
}elseif(isset($_POST['enter_employee']) && !empty($_POST['employee_id'])){
    $employee = Employees::find_by_id($_POST['employee_id']);
    $employee->firstname = $database->escape_value($_POST['firstname']);
    $employee->lastname = $database->escape_value($_POST['lastname']);
    $employee->id_number = $database->escape_value($_POST['id_number']);
    $employee->gender = $database->escape_value($_POST['gender']);
    $employee->phone = $database->escape_value($_POST['phone']);
    $employee->email = $database->escape_value($_POST['email']);
    $employee->address = $database->escape_value($_POST['address']);
    $employee->location = $database->escape_value($_POST['location']);
    $employee->date_joined = $database->escape_value($_POST['date_joined']);
    $employee->specialisation = $database->escape_value($_POST['specialisation']);
    if($employee->save()){
        echo "update";
    }else{
        echo "failed";
    }

}else{
    echo "form not submitted";
}

?>
<?php $database->close_connection(); ?>
