<?php require_once('../../includes/initialization.php')  ?>
<?php
if(isset($_POST['employee_id'])){
    $employee = Employees::find_by_id($_POST['employee_id']);
    $results = $employee->delete();
    if($results){
        echo "success";
    }else{
        echo "failed";
    }

}else{
    echo "Not submitted";
}
?>
<?php $database->close_connection(); ?>