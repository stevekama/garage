<?php require_once('../../includes/initialization.php'); ?>
<?php $employees = Employees::find_all(); ?>
<div class="panel panel-default">
    <div class="panel-heading">Available Employees</div>
    <div class="panel-body">
        <table class="table">
            <tbody>
            <?php foreach($employees as $employee){?>
                <tr>
                    <td><?php echo htmlentities($employee->full_names()); ?></td>
                    <td><?php echo htmlentities($employee->specialisation); ?></td>
                    <td>
                        <button id="<?php echo htmlentities($employee->id); ?>" class="employee_profile btn btn-sm btn-info">
                            PROFILE
                        </button>
                    </td>
                    <td>
                        <button id="<?php echo htmlentities($employee->id); ?>" class="edit_employee btn btn-xs btn-warning">EDIT</button>
                        <button id="<?php echo htmlentities($employee->id); ?>" class="delete_employee btn btn-xs btn-danger">DELETE</button>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<?php $database->close_connection(); ?>
