<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['employee_id'])){
    $employee = Employees::find_by_id($database->escape_value($_POST['employee_id']));
    echo json_encode($employee);
}else{
    echo '{"error":"form submission"}';
}

?>
<?php $database->close_connection(); ?>
