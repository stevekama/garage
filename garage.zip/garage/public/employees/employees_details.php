<?php require_once('../../includes/initialization.php'); ?>
<?php
$output = "";
if(isset($_POST['employee_id'])){
    $current_employee = Employees::find_by_id($_POST['employee_id']);
    $output .= "<table class='table table-bordered'>";
    $output .= "<tbody>";
    $output .="<tr>";
    $output .= "<th>Full Names: </th>";
    $output .= "<td>".htmlentities($current_employee->full_names())."</td>";
    $output .= "</tr>";

    $output .="<tr>";
    $output .= "<th>ID Number: </th>";
    $output .= "<td>".htmlentities($current_employee->id_number)."</td>";
    $output .= "</tr>";

    $output .="<tr>";
    $output .= "<th>Gender: </th>";
    $output .= "<td>".htmlentities($current_employee->gender)."</td>";
    $output .= "</tr>";

    $output .="<tr>";
    $output .= "<th>Phone Number: </th>";
    $output .= "<td>".htmlentities($current_employee->phone)."</td>";
    $output .= "</tr>";

    $output .="<tr>";
    $output .= "<th>Email Address: </th>";
    $output .= "<td>".htmlentities($current_employee->email)."</td>";
    $output .= "</tr>";

    $output .="<tr>";
    $output .= "<th>Address: </th>";
    $output .= "<td>".htmlentities($current_employee->address)."</td>";
    $output .= "</tr>";

    $output .="<tr>";
    $output .= "<th>Location: </th>";
    $output .= "<td>".htmlentities($current_employee->location)."</td>";
    $output .= "</tr>";

    $output .="<tr>";
    $output .= "<th>Date Joined: </th>";
    $output .= "<td>".htmlentities($current_employee->date_joined)."</td>";
    $output .= "</tr>";

    $output .="<tr>";
    $output .= "<th>Position: </th>";
    $output .= "<td>".htmlentities($current_employee->specialisation)."</td>";
    $output .= "</tr>";



    $output .= "</tbody>";
    $output .="</table>";

}
echo $output;



?>
<?php $database->close_connection(); ?>