<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['enter_client'])){
    $client = new Clients();
    $client->firstname = $database->escape_value($_POST['clients_firstname']);
    $client->lastname  = $database->escape_value($_POST['clients_lastname']);
    $client->id_number = $database->escape_value($_POST['clients_id_number']);
    $client->gender = $database->escape_value($_POST['clients_gender']);
    $client->phone = $database->escape_value($_POST['clients_phone']);
    $client->email = $database->escape_value($_POST['clients_email']);
    $client->address = $database->escape_value($_POST['clients_address']);
    $client->location = $database->escape_value($_POST['clients_location']);
    if($client->save()){
        echo "success";
    }else{
        echo "failed";
    }

}else{
    echo "has not submitted yet";
}
?>
<?php $database->close_connection(); ?>
