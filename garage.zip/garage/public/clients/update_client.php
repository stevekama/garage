<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['update_client']) && !empty($_POST['c_id'])){
    $client = Clients::find_by_id($database->escape_value($_POST['c_id']));
    $client->firstname = $database->escape_value($_POST['c_firstname']);
    $client->lastname = $database->escape_value($_POST['c_lastname']);
    $client->id_number = $database->escape_value($_POST['c_id_number']);
    $client->gender = $database->escape_value($_POST['c_gender']);
    $client->phone = $database->escape_value($_POST['c_phone']);
    $client->email = $database->escape_value($_POST['c_email']);
    $client->address = $database->escape_value($_POST['c_address']);
    $client->location = $database->escape_value($_POST['c_location']);
    if($client->save()){
        echo "success";
    }else{
        echo "failure";
    }

}else{
    echo "Failed to submit";
}

?>
<?php $database->close_connection(); ?>
