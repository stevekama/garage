<?php require_once('../../includes/initialization.php') ?>
<?php
$output = "";
if(isset($_POST['client_id'])){
    $client_vehicles = Vehicles::find_clients_vehicle($database->escape_value($_POST['client_id']));
    $output .= "<table class='table'>";
    $output .= "<tbody>";
    foreach($client_vehicles as $client_vehicle){
        $output .= "<tr>";
        $output .= "<td>".$client_vehicle->make."</td>";
        $output .= "<td>".$client_vehicle->model."</td>";
        $output .= "<td>".$client_vehicle->plate_number."</td>";
        $output .= "</tr>";
    }
    $output .= "</tbody>";
    $output .= "</table>";

}else{
    $output .= "Error";
}
echo $output;
?>
<?php $database->close_connection(); ?>