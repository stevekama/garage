<?php require_once('../../includes/initialization.php'); ?>
<?php $clients = Clients::find_all(); ?>
<div class="panel panel-default">
    <div class="panel-heading">Clients</div>
    <div class="panel-body">
        <table class="table">
            <tbody>
            <?php foreach($clients as $client){?>
                <tr>
                    <td><?php echo htmlentities($client->full_names()); ?></td>
                    <td><button type="button" id="<?php echo $client->id; ?>" class="view_client_profile btn btn-sm btn-primary">PROFILE</button></td>
                    <td>
                        <button type="button" id="<?php echo $client->id; ?>" class="add_clients_car btn btn-sm btn-success">ADD</button>
                        <button type="button" id="<?php echo $client->id; ?>" class="view_vehicles btn btn-sm btn-info">VEHICLES</button>
                    </td>
                    <td>
                        <button id="<?php echo $client->id; ?>" class="edit_client btn btn-xs btn-warning">EDIT</button>
                        <button id="<?php echo $client->id; ?>" class="delete_client btn btn-xs btn-danger">DELETE</button>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </div>
</div>
<?php $database->close_connection(); ?>
