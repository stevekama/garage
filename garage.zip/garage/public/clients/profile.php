<?php require_once('../../includes/initialization.php'); ?>
<?php
$output = "";
if(isset($_POST['client_id'])){
    $client = Clients::find_by_id($database->escape_value($_POST['client_id']));
    $output .= "<table class='table table-bordered'>";
    $output .= "<tbody>";
    $output .= "<tr>";
    $output .= "<th> Full Names: </th>";
    $output .= "<td>".$client->full_names()."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th> ID Number: </th>";
    $output .= "<td>".$client->id_number."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th> Gender: </th>";
    $output .= "<td>".$client->gender."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th> Phone Number: </th>";
    $output .= "<td>".$client->phone."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th> Email Address: </th>";
    $output .= "<td>".$client->email."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th> Address: </th>";
    $output .= "<td>".$client->address."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th> Location: </th>";
    $output .= "<td>".$client->location."</td>";
    $output .= "</tr>";


    $output .= "</tbody>";
    $output .= "</table>";

}else{
    $output .= "error in submission";
}
echo $output;
?>
<?php $database->close_connection(); ?>
