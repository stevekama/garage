<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['client_id'])){
    $clients_vehicle = Vehicles::find_num_clients_vehicles($database->escape_value($_POST['client_id']));
    $count = $database->num_rows($clients_vehicle);
    if($count == '0'){
        $client = Clients::find_by_id($database->escape_value($_POST['client_id']));
        if($client->delete()){
            echo "success";
        }else{
            echo "failed";
        }

    }else{
        echo "WithCar";

    }

}else{
    echo "failed to submit";
}

?>
<?php $database->close_connection(); ?>
