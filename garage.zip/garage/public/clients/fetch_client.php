<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['clients_id'])){
    $client = Clients::find_by_id($database->escape_value($_POST['clients_id']));
    echo json_encode($client);
}
?>
<?php $database->close_connection(); ?>
