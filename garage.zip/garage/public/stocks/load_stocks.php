<?php require_once('../../includes/initialization.php') ?>
<?php  $stocks = Stocks::find_all(); ?>
<div class="panel panel-default">
    <div class="panel-heading">All Stocks Available</div>
    <div class="panel-body">
        <table class="table">
            <tbody>
            <?php foreach($stocks as $stock):?>
                <tr>
                    <td><?php echo htmlentities($stock->stock); ?></td>
                    <td><?php echo htmlentities($stock->serial); ?></td>
                    <td>
                        <button type="button" id="<?php echo htmlentities($stock->id); ?>" class="btn btn-sm btn-info view_stock">VIEW</button>
                    </td>
                    <td>
                        <button type="button" id="<?php echo htmlentities($stock->id); ?>" class="btn btn-xs btn-warning edit_stock">EDIT</button>
                        <button type="button" id="<?php echo htmlentities($stock->id); ?>" class="btn btn-xs btn-danger delete_stock">DELETE</button>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>

        </table>

    </div>
</div>
<?php $database->close_connection(); ?>




