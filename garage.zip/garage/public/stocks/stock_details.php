<?php require_once('../../includes/initialization.php'); ?>
<?php
$output = "";
if(isset($_POST['stock_id'])){
    $stock = Stocks::find_by_id($database->escape_value($_POST['stock_id']));
    $output .= "<table class='table table-bordered'>";
    $output .= "<tbody>";
    $output .= "<tr>";
    $output .= "<th>Stock:</th>";
    $output .= "<td>".$stock->stock."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th>Serial:</th>";
    $output .= "<td>".$stock->serial."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th>Brand:</th>";
    $output .= "<td>".$stock->brand."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<th>Quantity Available:</th>";
    $output .= "<td>".$stock->qty_available."</td>";
    $output .= "</tr>";


    $output .= "<tr>";
    $output .= "<th>Received Quantity:</th>";
    $output .= "<td>".$stock->qty_received."</td>";
    $output .= "</tr>";


    $output .= "<tr>";
    $output .= "<th>Price per item:</th>";
    $output .= "<td>".$stock->price."</td>";
    $output .= "</tr>";


    $output .= "<tr>";
    $output .= "<th>Total Price:</th>";
    $output .= "<td>".$stock->total."</td>";
    $output .= "</tr>";


    $output .= "<tr>";
    $output .= "<th>Date Received:</th>";
    $output .= "<td>".$stock->date."</td>";
    $output .= "</tr>";

    $output .= "</tbody>";
    $output .="</table>";
    echo $output;
}else{
    echo "Form not submitted";
}

?>
<?php $database->close_connection(); ?>
