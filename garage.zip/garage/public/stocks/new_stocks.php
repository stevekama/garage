<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['enter_stock']) && empty($_POST['stock_id'])){
    $stock = new Stocks();
    $stock->stock         = $database->escape_value($_POST['stock']);
    $stock->serial        = $database->escape_value($_POST['serial']);
    $stock->brand         = $database->escape_value($_POST['brand']);
    $stock->qty_available = $database->escape_value($_POST['qty_received']);
    $stock->qty_received  = $database->escape_value($_POST['qty_received']);
    $stock->price         = $database->escape_value($_POST['price']);
    $stock->total         = $database->escape_value($stock->qty_received * $stock->price);
    $stock->date          = $database->escape_value($_POST['date']);
    if($stock->save()){
        echo "new";
    }else{
        echo "failed to add";
    }

}elseif(isset($_POST['enter_stock']) && !empty($_POST['stock_id'])){
    $stock = Stocks::find_by_id($database->escape_value($_POST['stock_id']));
    $stock->stock         = $database->escape_value($_POST['stock']);
    $stock->serial        = $database->escape_value($_POST['serial']);
    $stock->brand         = $database->escape_value($_POST['brand']);
    $stock->qty_available = $database->escape_value($_POST['qty_received']);
    $stock->qty_received  = $database->escape_value($_POST['qty_received']);
    $stock->price         = $database->escape_value($_POST['price']);
    $stock->total         = $database->escape_value($stock->qty_received * $stock->price);
    $stock->date          = $database->escape_value($_POST['date']);
    if($stock->save()){
        echo "Update";
    }else{
        echo "failed to update";
    }


}else{
    echo "form not submitted";
}


?>
<?php $database->close_connection(); ?>
