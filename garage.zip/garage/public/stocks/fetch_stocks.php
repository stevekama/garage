<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['id'])){
    $sock = Stocks::find_by_id($database->escape_value($_POST['id']));
    echo json_encode($sock);
}
?>
<?php $database->close_connection(); ?>
