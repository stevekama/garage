<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['id'])){
    $stock = Stocks::find_by_id($database->escape_value($_POST['id']));
    if($stock->delete()){
        echo "success";
    }else{
        echo "failed";
    }
}
?>
<?php $database->close_connection(); ?>
