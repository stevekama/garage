<?php require_once('../../includes/initialization.php'); ?>
<?php
$all_stocks = Stocks::find_all_stocks();
echo $database->num_rows($all_stocks);
?>
<?php $database->close_connection(); ?>
