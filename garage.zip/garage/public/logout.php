<?php require_once('../includes/initialization.php'); ?>
<?php if(!$session->is_logged_in()){ redirect_to(base_url().'login.php'); } ?>
<?php
$session->logout();
redirect_to(base_url().'login.php');
?>
