<script src="<?php echo base_url(); ?>public/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>public/js/bootstrap-datepicker.js"></script>
<script src="<?php echo base_url(); ?>public/js/garage.js"></script>
<script src="<?php echo base_url(); ?>public/js/chart.min.js"></script>
<script src="<?php echo base_url(); ?>public/js/easypiechart.js"></script>

<script src="<?php echo base_url(); ?>public/js/bootstrap-table.js"></script>
<script>
    steve('#calendar').datepicker({
    });

    !function (steve) {
        steve(document).on("click","ul.nav li.parent > a > span.icon", function(){
            $(this).find('em:first').toggleClass("glyphicon-minus");
        });
        steve(".sidebar span.icon").find('em:first').addClass("glyphicon-plus");
    }(window.jQuery);

    steve(window).on('resize', function () {
        if (steve(window).width() > 768) steve('#sidebar-collapse').collapse('show')
    })
    steve(window).on('resize', function () {
        if (steve(window).width() <= 767) steve('#sidebar-collapse').collapse('hide')
    })
</script>
</body>

</html>
<?php $database->close_connection(); ?>
