<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login || G-SYS</title>

    <link href="<?php echo base_url(); ?>public/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>public/css/datepicker3.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>public/css/styles.css" rel="stylesheet">

    <!--[if lt IE 9]>
    <script src="<?php echo base_url(); ?>public/js/html5shiv.js"></script>
    <script src="<?php echo base_url(); ?>public/js/respond.min.js"></script>
    <![endif]-->

</head>
<body>