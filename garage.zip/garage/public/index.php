<?php require_once('../includes/initialization.php');  ?>
<?php if(!$session->is_logged_in()){ redirect_to(base_url().'login.php'); } ?>
<?php require_once('layouts/system/header.php') ?>
<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">
	<div class="row">
		<ol class="breadcrumb">
			<li><a href="#"><svg class="glyph stroked home"><use xlink:href="#stroked-home"></use></svg></a></li>
			<li class="active">Icons</li>
		</ol>
	</div><!--/.row-->

	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">Dashboard</h1>
		</div>
	</div><!--/.row-->

	<div class="row">
		<span class="main_tasks">
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked bag"><use xlink:href="#stroked-bag"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large">
								<?php $all_clients = Clients::find_all_clients(); ?>
								<?php echo htmlentities($database->num_rows($all_clients)); ?>
							</div>
							<div class="text-muted">
								<button type="button" class="orders btn btn-xs btn-link">Orders</button>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-teal panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked male-user"><use xlink:href="#stroked-male-user"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large countEmployee">
								<?php $number_of_employees = Employees::find_all_employees(); ?>
								<?php echo $database->num_rows($number_of_employees); ?>
							</div>
							<div class="text-muted">
								<button id="employees" class="btn btn-xs btn-link">
									Emloyees
								</button>
							</div>
							<span><button class="new_employee btn btn-xs btn-success">NEW EMPLOYEE</button></span>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked gear"><use xlink:href="#stroked-gear"/></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="countServices large">
								<?php $all_services = Services::find_all_services();  ?>
								<?php echo $database->num_rows($all_services);  ?>
							</div>
							<div class="text-muted">
								<button type="button" id="services" class="btn btn-xs btn-link">
									Services
								</button>
							</div>
							<span><button class="new_service btn btn-xs btn-success">NEW SERVICE</button></span>
						</div>
					</div>
				</div>
			</div>

			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-red panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked app-window-with-content"><use xlink:href="#stroked-app-window-with-content"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large countStock">
								<?php $all_stocks = Stocks::find_all_stocks(); ?>
								<?php echo $database->num_rows($all_stocks); ?>
							</div>
							<div class="text-muted"><button class="stocks btn btn-xs btn-link">Stocks</button></div>
							<span><button class="new_stocks btn btn-xs btn-success">NEW STOCK</button></span>
						</div>
					</div>
				</div>
			</div>
		</span>

		<span class="orders_task">
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-blue panel-widget ">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked bag"><use xlink:href="#stroked-bag"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large">
								<?php $all_clients = Clients::find_all_clients(); ?>
								<?php echo htmlentities($database->num_rows($all_clients)); ?>
							</div>
							<div class="text-muted">
								<button class="btn btn-xs btn-link view_clients">
									Clients
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-12 col-md-6 col-lg-3">
				<div class="panel panel-orange panel-widget">
					<div class="row no-padding">
						<div class="col-sm-3 col-lg-5 widget-left">
							<svg class="glyph stroked empty-message"><use xlink:href="#stroked-empty-message"></use></svg>
						</div>
						<div class="col-sm-9 col-lg-7 widget-right">
							<div class="large">
								<?php $all_vehicles = Vehicles::find_all_vehicles(); ?>
								<?php echo htmlentities($database->num_rows($all_vehicles)); ?>
							</div>
							<div class="text-muted">
								<button class="btn btn-xs btn-link vehicles">Vehicles</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</span>

	</div><!--/.row-->
	<div class="row">
		<div class="col-lg-12 notice">

		</div>
	</div>
	<div class="row">
		<div id="load_data" class="col-lg-12">
			<div class="panel panel-default">
				<div class="panel-heading">
					New Client
				</div>
				<div class="panel-body">
					<form id="new_clients_form" method="post" role="form">
						<div class="form-group">
							<input type="text" id="clients_firstname" name="clients_firstname" class="form-control" placeholder="First Name">
						</div>
						<div class="form-group">
							<input type="text" id="clients_lastname" name="clients_lastname" class="form-control" placeholder="Last Name">
						</div>
						<div class="form-group">
							<input type="text" id="clients_id_number" name="clients_id_number" class="form-control" placeholder="ID Number">
						</div>
						<div class="form-group">
							<input type="text" id="clients_gender" name="clients_gender" class="form-control" placeholder="Gender">
						</div>
						<div class="form-group">
							<input type="text" id="clients_phone" name="clients_phone" class="form-control" placeholder="Phone Number">
						</div>
						<div class="form-group">
							<input type="text" id="clients_email" name="clients_email" class="form-control" placeholder="Email Address">
						</div>
						<div class="form-group">
							<input type="text" id="clients_address" name="clients_address" class="form-control" placeholder="Local Address">
						</div>
						<div class="form-group">
							<input type="text" id="clients_location" name="clients_location" class="form-control" placeholder="Location">
						</div>
						<button type="submit" id="enter_client" class="btn btn-primary">ENTER</button>
					</form>
				</div>
			</div>
		</div>
	</div><!--/.row-->
</div>
<!--employees profile modal-->
<div id="employee_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Stock Details</h4>
			</div>
			<div id="employee_details" class="modal-body">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<div id="addemployeedataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">New Employee</h4>
			</div>
			<div class="modal-body">
				<form id="add_new_employee" role="form" method="post">

					<div class="form-group">
						<input id="firstname" name="firstname" class="form-control" placeholder="First Name">
					</div>

					<div class="form-group">
						<input id="lastname" name="lastname" class="form-control" placeholder="Last Name">
					</div>

					<div class="form-group">
						<input id="id_number" name="id_number" class="form-control" placeholder="ID Number">
					</div>


					<div class="form-group">
						<select id="gender" name="gender"  class="form-control">
							<option></option>
							<option>MALE</option>
							<option>FEMALE</option>
						</select>
					</div>

					<div class="form-group">
						<input id="phone" name="phone" class="form-control" placeholder="Phone Number">
					</div>

					<div class="form-group">
						<input type="email" id="email" name="email" class="form-control" placeholder="Email Address">
					</div>

					<div class="form-group">
						<input id="address" name="address" class="form-control" placeholder="Local Address">
					</div>

					<div class="form-group">
						<input id="location" name="location" class="form-control" placeholder="Location">
					</div>

					<div class="form-group">
						<input type="date" id="date_joined" name="date_joined" class="form-control" placeholder="Date Joined">
					</div>

					<div class="form-group">
						<?php $current_services = Services::find_all(); ?>
						<select id="specialisation" name="specialisation" class="form-control">
							<?php foreach($current_services as $current_service){?>
								<option><?php echo $database->escape_value($current_service->service); ?></option>
							<?php } ?>
						</select>
					</div>


					<div class="form-group">
						<input type="hidden" id="employee_id" name="employee_id" class="form-control" placeholder="Employee ID">
					</div>

					<button type="submit" id="enter_employee" name="enter_employee" class="btn btn-success">Enter</button>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<!--services profile modal-->
<div id="servicesdataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Service Details</h4>
			</div>
			<div id="service_details" class="modal-body">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<div id="service_employeeDataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Service Employee</h4>
			</div>
			<div id="employee_service" class="modal-body">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<div id="add_service_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">New Service</h4>
			</div>
			<div class="modal-body">
				<form id="add_new_service" role="form" method="post">

					<div class="form-group">
						<input id="service" name="service" class="form-control" placeholder="Service Name">
					</div>

					<div class="form-group">
						<input id="price" name="price" class="form-control" placeholder="Price">
					</div>

					<div class="form-group">
						<textarea id="description" name="description" placeholder="Description" class="form-control">

						</textarea>
					</div>

					<div class="form-group">
						<input type="hidden" id="service_id" name="service_id" class="form-control" placeholder="Service ID">
					</div>

					<button type="submit" id="enter_service" name="enter_service" class="btn btn-success">Enter</button>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>




<!--stocks profile modal-->
<div id="stock_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Stock Details</h4>
			</div>
			<div id="stock_details" class="modal-body">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<!--add new stock modal-->
<div id="add_stock_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">New Stock</h4>
			</div>
			<div class="modal-body">
				<form id="add_new_stock" role="form" method="post">

					<div class="form-group">
						<input id="stock" name="stock" class="form-control" placeholder="Stock">
					</div>

					<div class="form-group">
						<input id="serial" name="serial" class="form-control" placeholder="Seral Number">
					</div>

					<div class="form-group">
						<input id="brand" name="brand" class="form-control" placeholder="Brand">
					</div>


					<div class="form-group">
						<input id="qty_received" name="qty_received" class="form-control" placeholder="Received Quantity">
					</div>

					<div class="form-group">
						<input id="price" name="price" class="form-control" placeholder="Cost per item">
					</div>

					<div class="form-group">
						<input type="date" id="date" name="date" class="form-control" placeholder="Date Received">
					</div>


					<div class="form-group">
						<input type="hidden" id="stock_id" name="stock_id" class="form-control" placeholder="Stock ID">
					</div>

					<button type="submit" id="enter_stock" name="enter_stock" class="btn btn-success">Enter</button>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<!--clients profile modal-->
<div id="client_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Clients Details</h4>
			</div>
			<div id="client_details" class="modal-body">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<!--add new clients vehicle modal-->
<div id="add_vehicle_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">New Vehicles</h4>
			</div>
			<div class="modal-body">
				<form id="add_new_vehicle" role="form" method="post">

					<div class="form-group">
						<input id="make" name="make" class="form-control" placeholder="Make">
					</div>

					<div class="form-group">
						<input id="model" name="model" class="form-control" placeholder="Model">
					</div>

					<div class="form-group">
						<input id="plate_number" name="plate_number" class="form-control" placeholder="Plate Number">
					</div>

					<div class="form-group">
						<input type="hidden" id="clients_id" name="clients_id" class="form-control" placeholder="Client ID">
					</div>

					<button type="submit" id="enter_vehicle" name="enter_vehicle" class="btn btn-success">Enter</button>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>


<!--edit clients details modal-->
<div id="edit_client_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Edit Clients Info</h4>
			</div>
			<div class="modal-body">
				<form id="edit_client_form" role="form" method="post">

					<div class="form-group">
						<input id="c_firstname" name="c_firstname" class="form-control" placeholder="First Name">
					</div>

					<div class="form-group">
						<input id="c_lastname" name="c_lastname" class="form-control" placeholder="Last Name">
					</div>

					<div class="form-group">
						<input id="c_id_number" name="c_id_number" class="form-control" placeholder="ID Number">
					</div>

					<div class="form-group">
						<input id="c_gender" name="c_gender" class="form-control" placeholder="Gender">
					</div>

					<div class="form-group">
						<input id="c_phone" name="c_phone" class="form-control" placeholder="Phone Number">
					</div>

					<div class="form-group">
						<input id="c_email" name="c_email" class="form-control" placeholder="Email Address">
					</div>

					<div class="form-group">
						<input id="c_address" name="c_address" class="form-control" placeholder="Address">
					</div>

					<div class="form-group">
						<input id="c_location" name="c_location" class="form-control" placeholder="Location">
					</div>

					<div class="form-group">
						<input type="hidden" id="c_id" name="c_id" class="form-control" placeholder="Client ID">
					</div>

					<button type="submit" id="update_client" name="update_client" class="btn btn-success">UPDATE</button>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<!--vehicle profile modal-->
<div id="vehicle_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Vehicle Details</h4>
			</div>
			<div id="vehicle_profile_details" class="modal-body">

			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>

<!--edit vehicle modal-->
<div id="edit_vehicle_dataModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Edit Vehicles</h4>
			</div>
			<div class="modal-body">
				<form id="edit_vehicle_form" role="form" method="post">

					<div class="form-group">
						<input id="v_make" name="v_make" class="form-control" placeholder="Make">
					</div>

					<div class="form-group">
						<input id="v_model" name="v_model" class="form-control" placeholder="Model">
					</div>

					<div class="form-group">
						<input id="v_plate_number" name="v_plate_number" class="form-control" placeholder="Plate Number">
					</div>

					<div class="form-group">
						<input type="hidden" id="vehicle_id" name="vehicle_id" class="form-control" placeholder="Vehicle ID">
					</div>

					<button type="submit" id="update_vehicle" name="update_vehicle" class="btn btn-success">UPDATE</button>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>



<?php require_once('layouts/system/footer.php'); ?>
