<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['vehicle_id'])){
    $vehicle  = Vehicles::find_by_id($database->escape_value($_POST['vehicle_id']));
    if($vehicle->delete()){
        echo "success";
    }else{
        echo "failed";
    }
}else{
    echo "failed to submit";
}
?>
<?php $database->close_connection(); ?>