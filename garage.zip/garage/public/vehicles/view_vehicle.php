<?php require_once('../../includes/initialization.php'); ?>
<?php
$output = "";
if(isset($_POST['vehicle_id'])){
    $vehicle = Vehicles::find_by_id($database->escape_value($_POST['vehicle_id']));
    $output .= "<table class='table table-bordered'>";
    $output .= "<tbody>";
    $output .= "<tr>";
    $output .= "<td>MAKE: </td>";
    $output .= "<td>".$vehicle->make."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<td>MODEL: </td>";
    $output .= "<td>".$vehicle->model."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<td>PLATE NUMBER: </td>";
    $output .= "<td>".$vehicle->plate_number."</td>";
    $output .= "</tr>";
    $output .= "</tbody>";
    $output .= "</table>";


}else{
    $output .= "Form Not Submitted";
}
echo $output;
?>
<?php $database->close_connection(); ?>
