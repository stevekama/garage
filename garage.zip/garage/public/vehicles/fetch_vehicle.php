<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['vehicle_id'])){
    $vehicle = Vehicles::find_by_id($database->escape_value($_POST['vehicle_id']));
    echo json_encode($vehicle);
}else{
    echo "form not submitted";
}

?>
<?php $database->close_connection(); ?>
