<?php require_once('../../includes/initialization.php'); ?>
<?php
$output = "";
if(isset($_POST['client_id'])){
    $vehicles = Vehicles::find_vehicle_by_client_id($_POST['client_id']);
    $output .= "<table class='table'>";
    $output .= "<thead>";
    $output .= "<tr>";
    $output .= "<th>MAKE</th>";
    $output .= "<th>MODEL</th>";
    $output .= "<th>PLATE NUMBER</th>";
    $output .= "</tr>";
    $output .= "</thead>";
    $output .= "<tbody>";
    while($vehicle = mysqli_fetch_assoc($vehicles)){
        $output .= "<tr>";
        $output .= "<td>".$vehicle['make']."</td>";
        $output .= "</tr>";

    }
    $output .= "</tbody>";
    $output .= "</table>";
}else{
    $output .= "form submission failed";
}

echo $output;

?>
<?php $database->close_connection(); ?>
