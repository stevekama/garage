<?php require_once('../../includes/initialization.php') ?>
<?php
if(isset($_POST['enter_vehicle']) && !empty($_POST['client_id'])){
    $vehicle = new Vehicles();
    $vehicle->client_id = $database->escape_value($_POST['client_id']);
    $vehicle->make = $database->escape_value($_POST['make']);
    $vehicle->model = $database->escape_value($_POST['model']);
    $vehicle->plate_number = $database->escape_value($_POST['plate_number']);
    if($vehicle->save()){
        echo "success";
    }else{
        echo "failed";
    }

}else{
    echo "failed submission";
}
?>
<?php $database->close_connection(); ?>
