<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['update_vehicle']) && !empty($_POST['vehicle_id'])){
    $vehicle = Vehicles::find_by_id($database->escape_value($_POST['vehicle_id']));
    $vehicle->make = $database->escape_value($_POST['v_make']);
    $vehicle->model = $database->escape_value($_POST['v_model']);
    $vehicle->plate_number = $database->escape_value($_POST['v_plate_number']);
    if($vehicle->save()){
        echo "updated";
    }else{
        echo "failed";
    }

}else{
    echo "Form submission error";
}

?>
<?php $database->close_connection(); ?>
