var steve = jQuery.noConflict();
steve(document).ready(function(){
    //orders button
    steve('.orders').click(function(){
        steve('.main_tasks').css("display", "none");
        steve('.orders_task').css("display", "inline-block");
        steve('#show_orders').css("display", "inline-block")
    });

    //clients
    //1. Load clients
    function load_all_clients(){
        steve.ajax({
            type:"POST",
            method:"POST",
            url:"clients/load_clients.php",
            data:"",
            dataType:"html",
            success:function(data){
                steve('#load_data').html(data);
            }
        });

    }

    steve('.view_clients').click(function(){
        load_all_clients();
    });
    //2. View client profile
    steve(document).on('click', '.view_client_profile', function(){
        var client_id = steve(this).attr('id');
        steve.ajax({
            url:"clients/profile.php",
            method:"POST",
            dataType:"text",
            data:{client_id:client_id},
            success:function(data){
                steve('#client_details').html(data);
                steve('#client_dataModal').modal('show');
            }
        });
    });

    //new client submission
    steve('#new_clients_form').on('submit', function(event){
        event.preventDefault();
        var clients_firstname = steve('#clients_firstname').val();
        var clients_lastname = steve('#clients_lastname').val();
        var clients_id_number = steve('#clients_id_number').val();
        var clients_gender = steve('#clients_gender').val();
        var clients_phone = steve('#clients_phone').val();
        var clients_email = steve('#clients_email').val();
        var clients_address = steve('#clients_address').val();
        var clients_location = steve('#clients_location').val();
        if(clients_firstname.length>0 && clients_lastname.length>0 && clients_id_number.length>0 && clients_gender.length>0 && clients_phone.length>0 && clients_email.length>0 && clients_address.length>0 && clients_location.length>0){
            var DataToSend = "clients_firstname="+clients_firstname+"&clients_lastname="+clients_lastname+"&clients_id_number="+clients_id_number+"&clients_gender="+clients_gender+"&clients_phone="+clients_phone+"&clients_email="+clients_email+"&clients_address="+clients_address+"&clients_location="+clients_location+"&enter_client";
            steve.ajax({
                url:"clients/new_client.php",
                method:"POST",
                dataType:"text",
                data:DataToSend,
                beforeSend:function(){
                    steve('#enter_client').text('connecting..');
                },
                success:function(data){
                    if(data == "success"){
                        //window.location='index.php';
                        steve('.main_tasks').css("display", "none");
                        steve('.orders_task').css("display", "inline-block");
                        steve('#enter_client').text('ENTER');
                        load_all_clients();
                        console.log(data);

                    }
                    //
                }
            });

        }else{
            alert('Make sure you entered all fields first.');
        }
    });

    //3. Work on clients vehicle
    //3.1 Add clients car
    steve(document).on('click', '.add_clients_car', function(){
        var client_id = steve(this).attr('id');
        steve.ajax({
            url:"clients/fetch_client.php",
            method:"POST",
            dataType:"json",
            data:{clients_id:client_id},
            success:function(data){
                steve('#clients_id').val(data.id);
                steve('#add_vehicle_dataModal').modal('show');
            }
        });
    });
    //new clients car submission
    steve('#add_new_vehicle').on('submit', function(event){
        event.preventDefault();
        var make = steve('#make').val();
        var model = steve('#model').val();
        var plate_number = steve('#plate_number').val();
        var client_id = steve('#clients_id').val();
        if(make.length>0 && model.length>0 && plate_number.length>0){
            var DataToSend = "make="+make+"&model="+model+"&plate_number="+plate_number+"&client_id="+client_id+"&enter_vehicle";
            steve.ajax({
                url:"vehicles/add_new_vehicle.php",
                method:"POST",
                dataType:"text",
                data:DataToSend,
                beforeSend:function(){
                    steve('#enter_vehicle').text('connecting..');
                },
                success:function(data){
                    steve('#add_new_vehicle')[0].reset();
                    steve('#add_vehicle_dataModal').modal('hide');
                    load_all_clients();
                }
            });
        }else{
            alert('There some empty fields. Please check then enter');
        }

    });

    //3.2 view clients car
    steve(document).on('click', '.view_vehicles', function(){
        var client_id = steve(this).attr('id');
        steve.ajax({
            url:"clients/view_vehicle.php",
            method:"POST",
            cache:false,
            data:{client_id:client_id},
            dataType:"text",
            success:function(data){
                console.log(data);
                steve('#vehicle_profile_details').html(data);
                steve('#vehicle_dataModal').modal('show');

            }
        });
    });
    //4. Edit clients profile
    steve(document).on('click', '.edit_client', function(){
        var clients_id = steve(this).attr('id');
        steve.ajax({
            url:"clients/fetch_client.php",
            method:"POST",
            dataType:"json",
            data:{clients_id:clients_id},
            success:function(data){
                steve('#c_id').val(data.id);
                steve('#c_firstname').val(data.firstname);
                steve('#c_lastname').val(data.lastname);
                steve('#c_id_number').val(data.id_number);
                steve('#c_gender').val(data.gender);
                steve('#c_phone').val(data.phone);
                steve('#c_email').val(data.email);
                steve('#c_address').val(data.address);
                steve('#c_location').val(data.location);
                steve('#edit_client_dataModal').modal('show');
            }

        });
    });
    //edit_client submission
    steve('#edit_client_form').on('submit', function(event){
        event.preventDefault();
        var first_name = steve('#c_firstname').val();
        var lastname = steve('#c_lastname').val();
        var id_number = steve('#c_id_number').val();
        var gender = steve('#c_gender').val();
        var phone = steve('#c_phone').val();
        var email = steve('#c_email').val();
        var address = steve('#c_address').val();
        var location = steve('#c_location').val();
        var client_id = steve('#c_id').val();
        if(first_name.length>0 && lastname.length>0 && id_number.length>0 && gender.length>0 && phone.length>0 && email.length>0 && address.length>0 && location.length>0){
            var DataToSend = "c_firstname="+first_name+"&c_lastname="+lastname+"&c_id_number="+id_number+"&c_gender="+gender+"&c_phone="+phone+"&c_email="+email+"&c_address="+address+"&c_location="+location+"&c_id="+client_id+"&update_client";
            steve.ajax({
                url:"clients/update_client.php",
                method:"POST",
                dataType:"text",
                data:DataToSend,
                beforeSend:function(){
                    steve('#update_client').text('connecting..');
                },
                success:function(data){
                    console.log(data);
                    if(data=="success"){
                        steve('#edit_client_form')[0].reset();
                        steve('#edit_client_dataModal').modal('hide');
                        load_all_clients();
                    }
                }
            });

        }else{
            alert('Some fields are empty. Please check and try again..');
        }
    });

    //5. Delete client profile
    steve(document).on('click', '.delete_client', function(){
        if(confirm('Are you sure you want to delete this..?')){
            var client_id = steve(this).attr('id');
            steve.ajax({
                url:"clients/delete_client.php",
                method:"POST",
                dataType:"text",
                cache:false,
                data:{client_id:client_id},
                success:function(data){
                    if(data == 'success'){
                        load_all_clients();
                    }else if(data == 'failed'){
                        steve('.notice').html("<div class='alert bg-danger' role='alert'>There was a problem in deleting <button class='close pull-right' data-dismiss='alert'>&times;</button></div>");
                        console.log(data);
                    }else if(data == 'WithCar'){
                        steve('.notice').html("<div class='alert bg-warning' role='alert'>The client has vehicles under him or her <button class='close pull-right' data-dismiss='alert'>&times;</button></div>");
                        console.log(data);
                    }else{
                        console.log(data);
                    }

                }
            });
        }else{
            return false;
        }
    });







    //employees
    function load_employees(){
        steve.ajax({
            type:"POST",
            method:"POST",
            url:"employees/load_employees.php",
            data:"",
            dataType:"html",
            success:function(data){
                steve('#load_data').html(data);
            }
        });
    }

    //1. Load all employees
    steve('#employees').click(function(){
        load_employees();
    });
    //2. Load employee profile
    function load_employee_profile(employee_id){
        steve.ajax({
            url:"employees/employees_details.php",
            method:"POST",
            data:{employee_id:employee_id},
            success:function(data){
                steve('#employee_details').html(data);
                steve('#employee_dataModal').modal('show');
            }
        });
    }
    steve(document).on('click', '.employee_profile', function(){
        var employee_id = steve(this).attr('id');
        load_employee_profile(employee_id);
    });

    //3. Add New Employee
    steve('.new_employee').click(function(){
        steve('#employee_id').val('');
        steve('.modal-title').text('New Employee');
        steve('#firstname').val('');
        steve('#lastname').val('');
        steve('#id_number').val('');
        steve('#gender').val('');
        steve('#phone').val('');
        steve('#email').val('');
        steve('#address').val('');
        steve('#location').val('');
        steve('#date_joined').val('');
        steve('#specialisation').val('');
        steve('#enter_employee').text('ENTER');

        steve('#addemployeedataModal').modal('show');
    });


    //4. Edit employee details
    steve(document).on('click', '.edit_employee', function(){
        var employee_id = steve(this).attr('id');
        steve.ajax({
            url:"employees/fetch_employee.php",
            method:"POST",
            data:{employee_id:employee_id},
            dataType:"json",
            success:function(data){
                steve('#employee_id').val(data.id);
                steve('.modal-title').text('Update Employee');
                steve('#firstname').val(data.firstname);
                steve('#lastname').val(data.lastname);
                steve('#id_number').val(data.id_number);
                steve('#gender').val(data.gender);
                steve('#phone').val(data.phone);
                steve('#email').val(data.email);
                steve('#address').val(data.address);
                steve('#location').val(data.location);
                steve('#date_joined').val(data.date_joined);
                steve('#specialisation').val(data.specialisation);
                steve('#enter_employee').text('UPDATE');

                steve('#addemployeedataModal').modal('show');
            }
        });
    });

    //submitting data
    steve('#add_new_employee').on('submit', function(event){
        event.preventDefault();
        var firstname = steve('#firstname').val();
        var lastname = steve('#lastname').val();
        var id_number = steve('#id_number').val();
        var gender = steve('#gender').val();
        var phone = steve('#phone').val();
        var email = steve('#email').val();
        var address = steve('#address').val();
        var location = steve('#location').val();
        var date_joined = steve('#date_joined').val();
        var specialisation = steve('#specialisation').val();
        var employee_id = steve('#employee_id').val();
        if(firstname.length > 0 && lastname.length > 0 && id_number.length > 0 && gender.length > 0 && phone.length > 0 && email.length > 0 && address.length > 0 && location.length > 0 && date_joined.length > 0 && specialisation.length > 0) {
            var dataToSend = "firstname="+firstname+"&lastname="+lastname+"&id_number="+id_number+"&gender="+gender+"&phone="+phone+"&email="+email+"&address="+address+"&location="+location+"&date_joined="+date_joined+"&specialisation="+specialisation+"&employee_id="+employee_id+"&enter_employee";
            steve.ajax({
                url:"employees/new_employee.php",
                method:"POST",
                data:dataToSend,
                beforeSend:function(){
                    steve('#enter_employee').text('connecting..');
                },
                success:function(data){
                    console.log(data);
                    if(data == 'new'){
                        steve('.messages').html("<div class='alert bg-success' role='alert'> <svg class='glyph stroked checkmark'><use xlink:href='#stroked-checkmark'></use></svg> Successfully added a new employee </div>");
                        steve('#add_new_employee')[0].reset();
                        steve('#addemployeedataModal').modal('hide');
                        load_employees();
                    }else if(data == 'update'){
                        steve('.messages').html("<div class='alert bg-success' role='alert'> <svg class='glyph stroked checkmark'><use xlink:href='#stroked-checkmark'></use></svg> Successfully updated employees details </div>");
                        steve('#add_new_employee')[0].reset();
                        steve('#addemployeedataModal').modal('hide');
                        load_employees();
                    }

                }

            });
        }else{
            alert('There is an empty field. Please check and try again..');
        }
    });

    //5. Delete employee
    steve(document).on('click', '.delete_employee', function(){
        if(confirm('Are you sure??')){
            var employee_id = steve(this).attr('id');
            steve.ajax({
                url:"employees/delete.php",
                method:"POST",
                data:{employee_id:employee_id},
                success:function(data){
                    if(data == 'success'){
                        load_employees();
                    }
                }
            });
        }else{
            return null;
        }
    });

    //6. check the number of employees
    function check_num_of_employees(){
        var num_employees = parseFloat(steve('.countEmployee').html());
        steve.ajax({
            type:"POST",
            method:"POST",
            url:"employees/num _of_employees.php",
            data:"",
            success:function(data){
                if(data != num_employees){
                    steve('.countEmployee').html(data);
                }
            }
        });
    }
    //check if the number is right after every one second
    setInterval(check_num_of_employees, 1000);

    //End of Employees
    ///start on services
    //1. load service
    function load_all_services(){
        steve.ajax({
            type:"POST",
            method:"POST",
            url:"services/load_services.php",
            data:"",
            dataType:"html",
            success:function(data){
                steve('#load_data').html(data);
            }
        });
    }
    steve('#services').click(function(){
        load_all_services();
    });

    ///load employeee
    function load_employee_service(service){
        steve.ajax({
            type:"POST",
            method:"POST",
            url:"services/load_employees.php",
            data:{service:service},
            dataType:"html",
            success:function(data){
                steve('#employee_service').html(data);
                steve('#service_employeeDataModal').modal('show');
            }
        });
    }
    steve(document).on('click', '.view_employee', function(){
        var service = steve(this).attr('id');
        load_employee_service(service);

    });

    //2.view service
    steve(document).on('click', '.view_services', function(){
        var service_id = steve(this).attr('id');
        steve.ajax({
            url:"services/view_services.php",
            method:"POST",
            data:{service_id:service_id},
            success:function(data){
                steve('#service_details').html(data);
                steve('#servicesdataModal').modal('show');
            }

        });
    });





    //3. new service
    steve('.new_service').click(function(){
        steve('#service').val('');
        steve('#price').val('');
        steve('#description').val('');
        steve('#service_id').val('');
        steve('#add_service_dataModal').modal('show');
    });

    //4. edit service
    steve(document).on('click', '.edit_service', function(){
        var service_id = steve(this).attr('id');
        steve.ajax({
            url:"services/fetch_services.php",
            method:"POST",
            data:{service_id:service_id},
            dataType:"json",
            success:function(data){
                steve('#service_id').val(data.id);
                steve('#service').val(data.service);
                steve('#price').val(data.price);
                steve('#description').val(data.description);
                steve('.modal-title').text("Edit Service");
                steve('#enter_service').text("UPDATE");
                steve('#add_service_dataModal').modal('show');

            }
        });
    });

    //working with submission form
    steve('#add_new_service').on('submit', function(event){
        event.preventDefault();
        var service = steve('#service').val();
        var price = steve('#price').val();
        var description = steve('#description').val();
        var service_id = steve('#service_id').val();
        if(service.length>0 && price.length>0 && description.length>0){
            var DataToSend = "service="+service+"&price="+price+"&description="+description+"&service_id="+service_id+"&enter_service";
            steve.ajax({
                url:"services/new_service.php",
                method:"POST",
                data:DataToSend,
                beforeSend:function(){
                    steve('#enter_service').text('connecting..');
                },
                success:function(data){
                    if(data == 'new'){
                        steve('.messages').html("<div class='alert bg-success' role='alert'> <svg class='glyph stroked checkmark'><use xlink:href='#stroked-checkmark'></use></svg> Successfully added a new service </div>");
                        steve('#add_new_service')[0].reset();
                        steve('#add_service_dataModal').modal('hide');
                        steve('#enter_service').text('ENTER');
                        load_all_services();
                    }else if(data == 'Update'){
                        steve('.messages').html("<div class='alert bg-success' role='alert'> <svg class='glyph stroked checkmark'><use xlink:href='#stroked-checkmark'></use></svg> Successfully updated current service </div>");
                        steve('#add_new_service')[0].reset();
                        steve('#add_service_dataModal').modal('hide');
                        steve('#enter_service').text('UPDATE');
                        load_all_services();
                    }
                }

            });
        }else{
            alert("Enter all the necessary fields before enter");
        }
    });

    //5. deleting services
    steve(document).on('click', '.delete_service', function(){
        if(confirm('Are you sure..?')){
            var service_id = steve(this).attr('id');
            steve.ajax({
                url:"services/delete_service.php",
                method:"POST",
                data:{service_id:service_id},
                success:function(data){
                    if(data == 'success'){
                        load_all_services();
                    }
                }
            });
        }else{
            return null;
        }
    });

    //6. check nu of services
    function num_of_services(){
        var num_services = parseFloat(steve('.countServices').html());
        steve.ajax({
            method:"POST",
            url:"services/num_of_services.php",
            data:"",
            cache:false,
            success:function(data){
                if(num_services != data){
                    console.log(data);
                    //steve('.countServices').html(data);
                }
            }

        });
    }
    setInterval(num_of_services, 1000);

    //end of services
    //start on the stocks
    //1. load stocks
    function load_all_stocks(){
        steve.ajax({
            type:"POST",
            method:"POST",
            url:"stocks/load_stocks.php",
            data:"",
            dataType:"html",
            success:function(data){
                steve('#load_data').html(data);
            }
        });
    }

    steve('.stocks').click(function(){
        load_all_stocks();
    });

    //2. view stock
    steve(document).on('click', '.view_stock', function(){
        var stock_id = steve(this).attr('id');
        steve.ajax({
            url:"stocks/stock_details.php",
            method:"POST",
            cache:false,
            data:{stock_id:stock_id},
            success:function(data){
                steve('#stock_details').html(data);
                steve('#stock_dataModal').modal('show');
            }
        });
    });
    //3. new stock
    steve('.new_stocks').click(function(){
        steve('#add_stock_dataModal').modal('show');
        steve('#add_new_stock')[0].reset();
        steve('#stock_id').val('');
    });

    //4. edit stock
    steve(document).on('click', '.edit_stock', function(){
        var id = steve(this).attr('id');
        steve.ajax({
            url:"stocks/fetch_stocks.php",
            method:"POST",
            data:{id:id},
            cache:false,
            dataType:"json",
            success:function(data){
                steve('#add_stock_dataModal').modal('show');
                steve('#stock').val(data.stock);
                steve('#serial').val(data.serial);
                steve('#brand').val(data.brand);
                steve('#qty_received').val(data.qty_received);
                steve('#price').val(data.price);
                steve('#date').val(data.date);
                steve('#stock_id').val(data.id);
                steve('.modal-title').text('Edit Stock');
                steve('#enter_stock').text('UPDATE');
            }
        });
    });

    //submit
    steve('#add_new_stock').on('submit', function(event){
        event.preventDefault();
        var stock    =  steve('#stock').val();
        var serial   =  steve('#serial').val();
        var brand =  steve('#brand').val();
        var qty_received =  steve('#qty_received').val();
        var price =  steve('#price').val();
        var date =  steve('#date').val();
        var stock_id =  steve('#stock_id').val();
        if(stock.length>0 && serial.length>0 && brand.length>0 && qty_received.length>0 && price.length>0 && date.length>0){
            var DataToSend = "stock="+stock+"&serial="+serial+"&brand="+brand+"&qty_received="+qty_received+"&price="+price+"&date="+date+"&stock_id="+stock_id+"&enter_stock";
            steve.ajax({
                url:"stocks/new_stocks.php",
                method:"POST",
                cache:false,
                data:DataToSend,
                dataType:"text",
                beforeSend:function(){
                    steve('#enter_stock').text('Connecting..');
                },
                success:function(data){
                    if(data == "new"){
                        steve('#add_new_stock')[0].reset();
                        steve('#add_stock_dataModal').modal('hide');
                        steve('#enter_stock').text('ENTER');
                        load_all_stocks();
                    }else if(data == 'Update'){
                        steve('#add_new_stock')[0].reset();
                        steve('#add_stock_dataModal').modal('hide');
                        steve('#enter_stock').text('UPDATE');
                        load_all_stocks();
                    }
                }
            });

        }else{
            alert('Make sure all fields are entered first before submission');
        }
    });

    //5. delete stocks
    steve(document).on('click', '.delete_stock', function(){
        if(confirm('Are you sure..?')){
            var id = steve(this).attr('id');
            steve.ajax({
                url:"stocks/delete_stock.php",
                method:"POST",
                data:{id:id},
                dataType:"text",
                success:function(data){
                    if(data == 'success'){
                        load_all_stocks();
                    }
                }
            });
        }else{
            return null;
        }
    });

    //6. check num of stocks
    function num_of_stocks(){
        //console.log('started...');
        var stocks  = parseInt(steve('.countStock').html());
        steve.ajax({
            type:"POST",
            url:"stocks/num_of_stocks.php",
            dataType:"text",
            crossdomain:true,
            cache:false,
            data:"",
            success:function(data){
                data = parseInt(data);
                if (stocks != data) {
                    steve('.countStock').html(data);
                }

            }
        });

    }
    setInterval(num_of_stocks,1000);

});