$(document).ready(function(){

    $('#user_login').on('submit', function(event){
        event.preventDefault();
        var email = $('#email').val();
        var password = $('#password').val();
        if(email.length<=0){
            $('#email_error').html("<span class='text-danger'>Email cannot be blank</span>");
        }else if(password.length<=0){
            $('#password_error').html("<span class='text-danger'>Password cannot be blank</span>");
        }else{

            var dataToSend = "email="+email+"&password="+password+"&login";//"";
            $.ajax({
                type:"POST",
                url:"public/users/login.php",
                dataType:"text",
                data:dataToSend,
                crossdomain:true,
                cache: false,
                beforeSend:function(){
                  $('#login').text('connecting..');
                },
                success:function(data){
                   if(data == 'success'){
                       $('#user_login')[0].reset();
                       window.location = "public/index.php";
                   }

                },
                error:function(){
                    console.log('error in submitting')
                }
            });

        }
    });


});