<?php header("Access-Control-Allow-Origin: *"); ?>
<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['login'])){
    $email = $database->escape_value($_POST['email']);
    $password = $database->escape_value($_POST['password']);
    $user = Users::authenticate($email, $password);
    if($user){
        $session->login($user);
        echo "success";
    }else{
        echo "failed to login";
    }
}else{
    echo "fail to submit";
}


?>
