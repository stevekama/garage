<?php require_once('../includes/initialization.php'); ?>
<?php
$number_of_employees = Employees::find_all_employees();
echo $database->num_rows($number_of_employees);
?>
<?php $database->close_connection(); ?>
