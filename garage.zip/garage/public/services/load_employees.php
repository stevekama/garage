<?php require_once('../../includes/initialization.php'); ?>
<?php if(isset($_POST['service'])){?>
    <?php $current_employees = Employees::find_employee_service($database->escape_value($_POST['service'])); ?>
    <table class="table table-bordered">
        <tbody>
        <?php foreach($current_employees as $current_employee){ ?>
            <tr>
                <td><?php echo htmlentities($current_employee->firstname); ?></td>
                <td><?php echo htmlentities($current_employee->lastname); ?></td>
                <td><?php echo htmlentities($current_employee->phone); ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
<?php } ?>
<?php $database->close_connection(); ?>
