<?php require_once('../../includes/initialization.php'); ?>
<?php
$output = "";
if(isset($_POST['service_id'])){
    $service = Services::find_by_id($database->escape_value($_POST['service_id']));
    $output .= "<table class='table table-bordered'>";
    $output .= "<tbody>";
    $output .= "<tr>";
    $output .= "<td>Service: </td>";
    $output .= "<td>".htmlentities($service->service)."</td>";
    $output .= "</tr>";

    $output .= "<tr>";
    $output .= "<td>Price: </td>";
    $output .= "<td>".htmlentities($service->price)."</td>";
    $output .= "</tr>";
    $output .= "<tr>";
    $output .= "<td>Details: </td>";
    $output .= "<td>".htmlentities($service->description)."</td>";
    $output .= "</tr>";
    $output .= "</tbody>";
    $output .= "</table>";
    echo $output;
}else{
    echo "Not submitted";
}
?>
<?php $database->close_connection(); ?>
