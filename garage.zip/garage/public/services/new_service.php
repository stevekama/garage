<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['enter_service']) && empty($_POST['service_id'])){
    $service = new Services();
    $service->service = $database->escape_value($_POST['service']);
    $service->price = $database->escape_value($_POST['price']);
    $service->description = $database->escape_value($_POST['description']);
    if($service->save()){
        echo "new";
    }else{
        echo "failed";
    }

}elseif(isset($_POST['enter_service']) && !empty($_POST['service_id'])){

    $service = Services::find_by_id($database->escape_value($_POST['service_id']));
    $service->service = $database->escape_value($_POST['service']);
    $service->price = $database->escape_value($_POST['price']);
    $service->description = $database->escape_value($_POST['description']);
    if($service->save()){
        echo "Update";
    }else{
        echo "failed to update";
    }
}

?>
<?php $database->close_connection(); ?>
