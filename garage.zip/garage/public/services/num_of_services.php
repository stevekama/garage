<?php require_once('../../includes/initialization.php'); ?>4
<?php
$all_services = Services::find_all_services();
$services_available = $database->num_rows($all_services);
echo $services_available;
?>
<?php $database->close_connection(); ?>