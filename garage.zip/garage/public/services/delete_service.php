<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['service_id'])){
    $service = Services::find_by_id($database->escape_value($_POST['service_id']));
    if($service->delete()){
        echo "success";
    }else{
        echo "failed";
    }
}

?>
<?php $database->close_connection(); ?>
