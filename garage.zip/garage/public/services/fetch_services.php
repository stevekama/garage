<?php require_once('../../includes/initialization.php'); ?>
<?php
if(isset($_POST['service_id'])){
    $service = Services::find_by_id($database->escape_value($_POST['service_id']));
    echo json_encode($service);
}

?>
<?php $database->close_connection(); ?>
