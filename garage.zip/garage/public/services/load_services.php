<?php require_once('../../includes/initialization.php'); ?>
<?php $services = Services::find_all(); ?>
    <div class="panel panel-default">
        <div class="panel-heading">All Services.</div>
        <div class="panel-body">
            <table class="table">
                <tbody>
                <?php foreach($services as $service){?>
                    <tr>
                        <td><?php echo htmlentities($service->service); ?></td>
                        <td><?php  echo htmlentities($service->price); ?></td>
                        <td>
                            <button type="button" id="<?php echo htmlentities($service->id); ?>" class="view_services btn btn-sm btn-info">
                                VIEW
                            </button>
                        </td>

                        <td>
                            <button type="button" id="<?php echo htmlentities($service->service); ?>" class="view_employee btn btn-sm btn-primary">EMPLOYEE.</button>
                        </td>

                        <td>
                            <button type="button" id="<?php echo htmlentities($service->id); ?>" class="edit_service btn btn-xs btn-warning">EDIT</button>
                            <button type="button" id="<?php echo htmlentities($service->id); ?>" class="delete_service btn btn-xs btn-danger">DELETE</button>
                        </td>

                    </tr>
                <?php } ?>
                </tbody>

            </table>
        </div>
    </div>
<?php $database->close_connection(); ?>