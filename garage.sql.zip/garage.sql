-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Nov 13, 2017 at 11:07 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `garage`
--

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `id_number` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(60) NOT NULL,
  `address` varchar(30) NOT NULL,
  `location` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`id`, `firstname`, `lastname`, `id_number`, `gender`, `phone`, `email`, `address`, `location`) VALUES
(1, 'Stephen ', 'Kamau', '31443160', 'MALE', '0715356718', 'stevekamahertz@gmail.com', '74782 - 00200 Nairobi', 'Nairobi, CBD'),
(3, 'Gorgina', 'Wangeci', '23968745', 'FEMALE', '0715356718', 'stevekamahertz@gmail.com', '123 Nairobi', 'Nairobi, CBD');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(11) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `id_number` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(60) NOT NULL,
  `location` varchar(30) NOT NULL,
  `date_joined` varchar(30) NOT NULL,
  `specialisation` varchar(60) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`id`, `firstname`, `lastname`, `id_number`, `gender`, `phone`, `email`, `address`, `location`, `date_joined`, `specialisation`) VALUES
(1, 'Kelvin', 'Mulima', '2236594', 'MALE', '0701568978', 'kelvin@gmail.com', '123 Nairobi', 'Nairobi, GPO', '2016-04-12', 'MECHANIC'),
(2, 'Stephen', 'Kinyanjui', '31443160', 'MALE', '0715356718', 'stevekamahertz@gmail.com', '123 Nairobi', 'Nairobi', '2017-01-02', 'ENGINE '),
(4, 'Catherine', 'Wangari', '32457896', 'FEMALE', '0710235689', 'stevekama@gmail.com', '123 Nairobi ', 'Nairobi, CBD', '2017-11-02', 'MECHANIC'),
(5, 'Grace ', 'Kuria', '25698745', 'FEMALE', '0701568978', 'stevekama@gmail.com', '123 Nairobi ', 'Nairobi, GPO', '2017-11-02', 'ENGINE WASH'),
(6, 'Brian', 'Josiah', '28456978', 'MALE', '0736987890', 'josiahbryan15@gmail.com', '123 Nairobi ', 'Nairobi, CBD', '2017-11-07', 'MECHANIC'),
(11, 'Abib', 'Sein', '31443160', 'FEMALE', '0715356718', 'stevekamahertz@gmail.com', '123 Nairobi ', 'Nairobi, CBD', '2017-11-01', 'MECHANIC');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE IF NOT EXISTS `services` (
  `id` int(11) NOT NULL,
  `service` varchar(60) NOT NULL,
  `price` varchar(30) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service`, `price`, `description`) VALUES
(4, 'Body Wash ', '800', 'We do body wash for all kind of vehicles. You are welcomed to visit us '),
(5, 'Car Wash ', '500', 'This will apply to all commercial vehicles only ');

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE IF NOT EXISTS `stocks` (
  `id` int(11) NOT NULL,
  `stock` varchar(60) NOT NULL,
  `serial` varchar(30) NOT NULL,
  `brand` varchar(60) NOT NULL,
  `qty_available` varchar(30) NOT NULL,
  `qty_received` varchar(30) NOT NULL,
  `price` varchar(30) NOT NULL,
  `total` varchar(30) NOT NULL,
  `date` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `stock`, `serial`, `brand`, `qty_available`, `qty_received`, `price`, `total`, `date`) VALUES
(1, 'stiring wheel ', '454545', 'Yana', '5', '5', '200', '1000', '2017-11-09'),
(7, 'Tyres', '25652aa', 'Yana', '12', '12', '450', '5400', '2017-11-01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(60) NOT NULL,
  `lastname` varchar(60) NOT NULL,
  `phone` varchar(60) NOT NULL,
  `email` varchar(60) NOT NULL,
  `username` varchar(60) NOT NULL,
  `usertype` varchar(30) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `phone`, `email`, `username`, `usertype`, `password`) VALUES
(1, 'Stephen', 'Kamau', '0715356718', 'stevekamahertz@gmail.com', 'Tycoon', 'ADMIN', 'stevekama');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE IF NOT EXISTS `vehicle` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `make` varchar(60) NOT NULL,
  `model` varchar(60) NOT NULL,
  `plate_number` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`id`, `client_id`, `make`, `model`, `plate_number`) VALUES
(1, 1, 'Toyota', 'sun', 'KBA 407B'),
(3, 3, 'Toyota', 'V8', 'KCB 889A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vehicle`
--
ALTER TABLE `vehicle`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
